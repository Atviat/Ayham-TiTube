# Ayham Tube

مشروع Android TV أولي بهوية أسود وبنفسجي ملكي، مبني باستخدام Kotlin وJetpack Compose وMaterial 3.

## البناء
- Android Gradle Plugin: 8.10.1
- Gradle: 8.11.1
- JDK: 17
- compileSdk: 35
- minSdk: 23

## بناء APK
من GitHub Actions شغّل workflow باسم **Ayham Tube Android Build**، ثم نزّل artifact باسم `Ayham-Tube-APK`.

## ملاحظات مهمة
هذه نسخة أساس بواجهة تلفاز وتجربة تنقل أولية بالريموت. لا تتضمن حالياً تسجيل دخول YouTube أو البحث الحقيقي أو تشغيل الفيديوهات. يجب تنفيذ تكامل YouTube لاحقاً باستخدام واجهات وطرق تشغيل رسمية ومتوافقة مع شروط YouTube. لا تتضمن حجب إعلانات أو تجاوز قيود المنصة.

Package: `com.ayham.tube`
