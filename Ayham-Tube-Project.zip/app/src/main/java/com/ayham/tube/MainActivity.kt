package com.ayham.tube

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF08070D)
private val Panel = Color(0xFF15121D)
private val Purple = Color(0xFF8B45F7)
private val TextPrimary = Color(0xFFF7F4FC)
private val TextMuted = Color(0xFFAAA4B5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                AyhamTubeScreen()
            }
        }
    }
}

@Composable
private fun AyhamTubeScreen() {
    val menu = listOf("الرئيسية", "استكشاف", "الاشتراكات", "المكتبة", "الإعدادات")
    val categories = listOf("الكل", "الموسيقى", "الألعاب", "الرياضة", "الأخبار", "التقنية")
    var selectedMenu by remember { mutableIntStateOf(0) }
    var selectedCategory by remember { mutableIntStateOf(0) }
    var searchText by remember { mutableStateOf("ابحث عن فيديوهاتك المفضلة") }

    Row(
        modifier = Modifier.fillMaxSize().background(Background).padding(30.dp)
    ) {
        Column(
            modifier = Modifier.width(190.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("AYHAM", color = TextPrimary, fontSize = 23.sp, fontWeight = FontWeight.Black)
                Text(" TUBE", color = Purple, fontSize = 23.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(18.dp))
            menu.forEachIndexed { index, item ->
                FocusMenuItem(
                    label = item,
                    selected = selectedMenu == index,
                    onClick = { selectedMenu = index }
                )
            }
            Spacer(Modifier.weight(1f))
            Text("VERSION 1.0.0", color = TextMuted, fontSize = 10.sp)
        }

        Column(
            modifier = Modifier.weight(1f).padding(start = 34.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("أهلاً بك في Ayham Tube", color = TextPrimary, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                    Text("اكتشف محتوى يناسب اهتماماتك", color = TextMuted, fontSize = 15.sp)
                }
                Spacer(Modifier.weight(1f))
                Surface(
                    color = Panel,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color(0xFF332641))
                ) {
                    Text(searchText, color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 13.dp))
                }
            }

            Spacer(Modifier.height(28.dp))
            Text("التصنيفات", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                categories.forEachIndexed { index, item ->
                    FocusChip(item, selectedCategory == index) { selectedCategory = index }
                }
            }

            Spacer(Modifier.height(30.dp))
            Text(
                text = when (selectedMenu) {
                    1 -> "استكشف المحتوى"
                    2 -> "اشتراكاتك"
                    3 -> "مكتبتك"
                    4 -> "إعدادات التطبيق"
                    else -> "ابدأ المشاهدة"
                },
                color = TextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(14.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                FeatureCard("الفيديوهات الرائجة", "اكتشف الأكثر مشاهدة")
                FeatureCard("قنواتك المفضلة", "تابع القنوات التي تحبها")
                FeatureCard("شاهد لاحقاً", "احتفظ بما تريد مشاهدته")
            }

            Spacer(Modifier.weight(1f))
            Text(
                "واجهة تجريبية — سيتم ربط خدمات YouTube الرسمية في مرحلة التكامل",
                color = TextMuted,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun FocusMenuItem(label: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused }.focusable(),
        color = if (selected || focused) Purple.copy(alpha = 0.22f) else Color.Transparent,
        shape = RoundedCornerShape(12.dp),
        border = if (selected || focused) BorderStroke(1.dp, Purple) else null
    ) {
        Text(
            label,
            color = if (selected || focused) TextPrimary else TextMuted,
            fontSize = 16.sp,
            fontWeight = if (selected || focused) FontWeight.Bold else FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp)
        )
    }
}

@Composable
private fun FocusChip(label: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Surface(
        onClick = onClick,
        modifier = Modifier.onFocusChanged { focused = it.isFocused }.focusable(),
        color = if (selected || focused) Purple else Panel,
        shape = RoundedCornerShape(20.dp),
        border = if (focused) BorderStroke(2.dp, TextPrimary) else null
    ) {
        Text(label, color = TextPrimary, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 17.dp, vertical = 10.dp))
    }
}

@Composable
private fun FeatureCard(title: String, subtitle: String) {
    var focused by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier.width(190.dp).height(145.dp)
            .clip(RoundedCornerShape(17.dp))
            .background(Panel)
            .border(
                width = if (focused) 2.dp else 1.dp,
                color = if (focused) Purple else Color(0xFF30283A),
                shape = RoundedCornerShape(17.dp)
            )
            .onFocusChanged { focused = it.isFocused }
            .focusable()
            .padding(17.dp),
        verticalArrangement = Arrangement.Bottom
    ) {
        Box(
            modifier = Modifier.fillMaxWidth().height(5.dp)
                .clip(RoundedCornerShape(5.dp)).background(Purple)
        )
        Spacer(Modifier.height(18.dp))
        Text(title, color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(subtitle, color = TextMuted, fontSize = 12.sp)
    }
}
